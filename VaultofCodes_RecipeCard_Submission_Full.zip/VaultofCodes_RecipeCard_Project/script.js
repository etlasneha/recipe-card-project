function toggleSection(id) {
    const el = document.getElementById(id);
    el.classList.toggle("hidden");
}

let stepIndex = 0;
function startCooking() {
    const steps = document.querySelectorAll("#steps li");
    if (steps.length === 0) return;
    stepIndex = 0;
    steps.forEach(step => step.style.background = "");
    highlightStep(steps);
}

function highlightStep(steps) {
    if (stepIndex < steps.length) {
        steps[stepIndex].style.background = "#d1f7d6";
        document.getElementById("progress").style.width = ((stepIndex + 1) / steps.length * 100) + "%";
        stepIndex++;
        setTimeout(() => highlightStep(steps), 2000);
    }
}
